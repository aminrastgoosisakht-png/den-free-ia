#include "den/geometry.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <utility>

namespace den {
namespace {
constexpr double kPi = 3.14159265358979323846;
double cross(Point a, Point b, Point c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}
bool on_segment(Point p,Point a,Point b,double t){return std::abs(cross(a,b,p))<=t && p.x>=std::min(a.x,b.x)-t&&p.x<=std::max(a.x,b.x)+t&&p.y>=std::min(a.y,b.y)-t&&p.y<=std::max(a.y,b.y)+t;}
bool segments_intersect(Point a,Point b,Point c,Point d,double t){
  double o1=cross(a,b,c),o2=cross(a,b,d),o3=cross(c,d,a),o4=cross(c,d,b);
  if(((o1>t&&o2< -t)||(o1< -t&&o2>t))&&((o3>t&&o4< -t)||(o3< -t&&o4>t)))return true;
  return (std::abs(o1)<=t&&on_segment(c,a,b,t))||(std::abs(o2)<=t&&on_segment(d,a,b,t))||(std::abs(o3)<=t&&on_segment(a,c,d,t))||(std::abs(o4)<=t&&on_segment(b,c,d,t));
}
double segment_distance(Point p, Point a, Point b){
  const double dx=b.x-a.x,dy=b.y-a.y,den=dx*dx+dy*dy;
  if(den==0) return distance(p,a);
  double u=((p.x-a.x)*dx+(p.y-a.y)*dy)/den; u=std::clamp(u,0.0,1.0);
  return distance(p,{a.x+u*dx,a.y+u*dy});
}
void rdp(const std::vector<Point>& p,std::size_t first,std::size_t last,double tol,std::vector<bool>& keep,double& maxdev){
  if(last<=first+1)return; double md=-1;std::size_t idx=first;
  for(std::size_t i=first+1;i<last;i++){double d=segment_distance(p[i],p[first],p[last]);if(d>md){md=d;idx=i;}}
  maxdev=std::max(maxdev,md);if(md>tol){keep[idx]=true;rdp(p,first,idx,tol,keep,maxdev);rdp(p,idx,last,tol,keep,maxdev);}
}
std::string trim(std::string s){while(!s.empty()&&(s.back()=='\r'||s.back()==' '||s.back()=='\t'))s.pop_back();std::size_t i=0;while(i<s.size()&&(s[i]==' '||s[i]=='\t'))i++;return s.substr(i);}
}

double distance(Point a, Point b){return std::hypot(a.x-b.x,a.y-b.y);}

bool read_ascii_dxf(const std::string& path, Drawing& out, std::string& error){
  std::ifstream f(path);if(!f){error="Cannot open input DXF";return false;}
  std::vector<std::pair<int,std::string>> pairs;std::string cs,vs;
  while(std::getline(f,cs)){if(!std::getline(f,vs))break;try{pairs.emplace_back(std::stoi(trim(cs)),trim(vs));}catch(...){error="Invalid DXF group code";return false;}}
  Drawing parsed;bool in_entities=false,found_entities=false;
  for(std::size_t i=0;i<pairs.size();){
    if(pairs[i].first==2&&pairs[i].second=="ENTITIES"){in_entities=true;found_entities=true;i++;continue;}
    if(in_entities&&pairs[i].first==0&&pairs[i].second=="ENDSEC"){in_entities=false;break;}
    if(!in_entities||pairs[i].first!=0){i++;continue;}
    std::string kind=pairs[i++].second;std::vector<std::pair<int,std::string>> data;
    while(i<pairs.size()&&pairs[i].first!=0)data.push_back(pairs[i++]);
    Entity e;bool supported=true;
    if(kind=="LINE")e.type=Entity::Type::Line;
    else if(kind=="LWPOLYLINE")e.type=Entity::Type::Polyline;
    else if(kind=="ARC")e.type=Entity::Type::Arc;
    else if(kind=="CIRCLE")e.type=Entity::Type::Circle;
    else supported=false;
    if(!supported){parsed.unsupported_entities++;continue;}
    try{
      if(e.type==Entity::Type::Polyline){double x=0,y=0;bool hx=false,hy=false;double bulge=0;
        for(const auto&g:data){int c=g.first;const auto&v=g.second;
          if(c==8)e.layer=v;else if(c==70)e.closed=(std::stoi(v)&1)!=0;
          else if(c==10){x=std::stod(v);hx=true;}
          else if(c==20){y=std::stod(v);hy=true;if(hx){e.points.push_back({x,y});e.bulges.push_back(bulge);bulge=0;hx=hy=false;}}
          else if(c==42){if(!e.bulges.empty())e.bulges.back()=std::stod(v);}
        }
        if(e.points.size()<2)continue;
      }else{
        for(const auto&g:data){int c=g.first;const auto&v=g.second;if(c==8)e.layer=v;
          if(e.type==Entity::Type::Line){if(c==10)e.a.x=std::stod(v);else if(c==20)e.a.y=std::stod(v);else if(c==11)e.b.x=std::stod(v);else if(c==21)e.b.y=std::stod(v);}
          else {if(c==10)e.center.x=std::stod(v);else if(c==20)e.center.y=std::stod(v);else if(c==40)e.radius=std::stod(v);else if(c==50)e.start_angle=std::stod(v);else if(c==51)e.end_angle=std::stod(v);}}
        if(e.type==Entity::Type::Line)e.points={e.a,e.b};
      }
    }catch(...){error="Invalid numeric entity data in "+kind;return false;}
    parsed.entities.push_back(std::move(e));
  }
  if(!found_entities){error="DXF ENTITIES section not found";return false;}out=std::move(parsed);return true;
}

bool write_ascii_dxf(const std::string& path,const Drawing& d,std::string& error){
  std::ofstream f(path);if(!f){error="Cannot create output DXF";return false;}f<<std::setprecision(15);
  f<<"0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1015\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n";
  for(const auto&e:d.entities){
    if(e.type==Entity::Type::Line)f<<"0\nLINE\n8\n"<<e.layer<<"\n10\n"<<e.a.x<<"\n20\n"<<e.a.y<<"\n30\n0\n11\n"<<e.b.x<<"\n21\n"<<e.b.y<<"\n31\n0\n";
    else if(e.type==Entity::Type::Polyline){if(e.points.size()<2)continue;f<<"0\nLWPOLYLINE\n8\n"<<e.layer<<"\n90\n"<<e.points.size()<<"\n70\n"<<(e.closed?1:0)<<"\n";for(std::size_t i=0;i<e.points.size();i++){f<<"10\n"<<e.points[i].x<<"\n20\n"<<e.points[i].y<<"\n";if(i<e.bulges.size()&&std::abs(e.bulges[i])>1e-14)f<<"42\n"<<e.bulges[i]<<"\n";}}
    else if(e.type==Entity::Type::Arc)f<<"0\nARC\n8\n"<<e.layer<<"\n10\n"<<e.center.x<<"\n20\n"<<e.center.y<<"\n30\n0\n40\n"<<e.radius<<"\n50\n"<<e.start_angle<<"\n51\n"<<e.end_angle<<"\n";
    else if(e.type==Entity::Type::Circle)f<<"0\nCIRCLE\n8\n"<<e.layer<<"\n10\n"<<e.center.x<<"\n20\n"<<e.center.y<<"\n30\n0\n40\n"<<e.radius<<"\n";
  }
  f<<"0\nENDSEC\n0\nEOF\n";if(!f.good()){error="Failed while writing output DXF";return false;}return true;
}

RepairReport remove_duplicate_lines(Drawing& d,double tol){
  RepairReport r;std::vector<Entity> kept;for(const auto&e:d.entities){bool dup=false;if(e.type==Entity::Type::Line){for(const auto&k:kept)if(k.type==Entity::Type::Line&&k.layer==e.layer){bool s=distance(e.a,k.a)<=tol&&distance(e.b,k.b)<=tol;bool rev=distance(e.a,k.b)<=tol&&distance(e.b,k.a)<=tol;if(s||rev){dup=true;break;}}}if(dup)r.duplicates_removed++;else kept.push_back(e);}d.entities=std::move(kept);return r;
}
std::size_t join_nearby_polyline_ends(Drawing&d,double tol){std::size_t n=0;for(std::size_t i=0;i<d.entities.size();i++)for(std::size_t j=i+1;j<d.entities.size();j++){auto&a=d.entities[i];auto&b=d.entities[j];if(a.type!=Entity::Type::Polyline||b.type!=Entity::Type::Polyline||a.closed||b.closed||a.layer!=b.layer||a.points.empty()||b.points.empty())continue;
  auto curved=[](const Entity& e){return std::any_of(e.bulges.begin(),e.bulges.end(),[](double v){return std::abs(v)>1e-14;});};if(curved(a)||curved(b))continue;Point*pa[]={&a.points.front(),&a.points.back()};Point*pb[]={&b.points.front(),&b.points.back()};double best=tol+1;int ai=-1,bi=-1;for(int x=0;x<2;x++)for(int y=0;y<2;y++){double dd=distance(*pa[x],*pb[y]);if(dd<=tol&&dd<best){best=dd;ai=x;bi=y;}}if(ai>=0){Point mid{(pa[ai]->x+pb[bi]->x)/2,(pa[ai]->y+pb[bi]->y)/2};*pa[ai]=mid;*pb[bi]=mid;n++;}}return n;}

std::size_t merge_connected_polylines(Drawing&d,double tol){
  std::size_t merged=0;bool changed=true;while(changed){changed=false;for(std::size_t i=0;i<d.entities.size()&&!changed;i++){auto&a=d.entities[i];if(a.type!=Entity::Type::Polyline||a.closed||a.points.size()<2)continue;for(std::size_t j=i+1;j<d.entities.size();j++){auto&b=d.entities[j];if(b.type!=Entity::Type::Polyline||b.closed||b.points.size()<2||a.layer!=b.layer)continue;
      auto has_bulge=[](const Entity& e){return std::any_of(e.bulges.begin(),e.bulges.end(),[](double v){return std::abs(v)>1e-14;});};
      if(has_bulge(a)||has_bulge(b))continue;
      int mode=-1;if(distance(a.points.back(),b.points.front())<=tol)mode=0;else if(distance(a.points.back(),b.points.back())<=tol)mode=1;else if(distance(a.points.front(),b.points.back())<=tol)mode=2;else if(distance(a.points.front(),b.points.front())<=tol)mode=3;if(mode<0)continue;
      if(mode==1||mode==3){std::reverse(b.points.begin(),b.points.end());std::reverse(b.bulges.begin(),b.bulges.end());}
      if(mode==2||mode==3){std::reverse(a.points.begin(),a.points.end());std::reverse(a.bulges.begin(),a.bulges.end());}
      Point mid{(a.points.back().x+b.points.front().x)/2,(a.points.back().y+b.points.front().y)/2};a.points.back()=mid;b.points.front()=mid;
      if(a.bulges.empty())a.bulges.resize(a.points.size(),0);if(b.bulges.empty())b.bulges.resize(b.points.size(),0);
      a.points.insert(a.points.end(),b.points.begin()+1,b.points.end());a.bulges.back()=0;a.bulges.insert(a.bulges.end(),b.bulges.begin()+1,b.bulges.end());d.entities.erase(d.entities.begin()+static_cast<std::ptrdiff_t>(j));merged++;changed=true;break;
    }}}return merged;
}

SimplifyReport simplify_polylines(Drawing&d,double tol){SimplifyReport rep;for(auto&e:d.entities)if(e.type==Entity::Type::Polyline&&!e.closed&&e.points.size()>2){bool curved=std::any_of(e.bulges.begin(),e.bulges.end(),[](double b){return std::abs(b)>1e-14;});if(curved)continue;rep.before+=e.points.size();auto p=e.points;std::vector<bool>keep(p.size(),false);keep.front()=keep.back()=true;std::vector<std::size_t>anchors{0};
  for(std::size_t i=1;i+1<p.size();i++){Point u{p[i].x-p[i-1].x,p[i].y-p[i-1].y},v{p[i+1].x-p[i].x,p[i+1].y-p[i].y};double lu=std::hypot(u.x,u.y),lv=std::hypot(v.x,v.y);if(lu>0&&lv>0){double cs=std::clamp((u.x*v.x+u.y*v.y)/(lu*lv),-1.0,1.0);if(std::acos(cs)>25*kPi/180){keep[i]=true;anchors.push_back(i);}}}
  anchors.push_back(p.size()-1);double dev=0;for(std::size_t a=0;a+1<anchors.size();a++)rdp(p,anchors[a],anchors[a+1],tol,keep,dev);std::vector<Point>out;for(std::size_t i=0;i<p.size();i++)if(keep[i])out.push_back(p[i]);rep.after+=out.size();rep.max_deviation=std::max(rep.max_deviation,dev);if(out.size()<p.size())rep.polylines_changed++;e.points=std::move(out);if(e.bulges.size()>e.points.size())e.bulges.resize(e.points.size());}return rep;}

QualityReport inspect_quality(const Drawing&d,double tol){QualityReport q;q.entity_count=d.entities.size();for(const auto&e:d.entities){if(e.type==Entity::Type::Line&&distance(e.a,e.b)<=tol)q.zero_length_lines++;if((e.type==Entity::Type::Arc||e.type==Entity::Type::Circle)&&e.radius<=tol)q.invalid_radii++;if(e.type!=Entity::Type::Polyline)continue;if(e.points.size()<2)q.short_polylines++;if(!e.closed&&e.points.size()>1&&distance(e.points.front(),e.points.back())>tol)q.open_polylines++;const std::size_t n=e.points.size();if(n<4)continue;for(std::size_t i=0;i+1<n;i++)for(std::size_t j=i+2;j+1<n;j++){if(i==0&&j+1==n-1&&e.closed)continue;if(segments_intersect(e.points[i],e.points[i+1],e.points[j],e.points[j+1],tol))q.self_intersections++;}}
  for(std::size_t i=0;i<d.entities.size();i++)if(d.entities[i].type==Entity::Type::Line)for(std::size_t j=i+1;j<d.entities.size();j++)if(d.entities[j].type==Entity::Type::Line&&d.entities[i].layer==d.entities[j].layer){auto&a=d.entities[i];auto&b=d.entities[j];if((distance(a.a,b.a)<=tol&&distance(a.b,b.b)<=tol)||(distance(a.a,b.b)<=tol&&distance(a.b,b.a)<=tol))q.duplicate_lines++;}return q;}
}
