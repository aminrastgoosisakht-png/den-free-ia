#pragma once
#include <cstddef>
#include <string>
#include <vector>

namespace den {
struct Point { double x{}, y{}; };
struct Entity {
  enum class Type { Line, Polyline, Arc, Circle } type{Type::Line};
  std::string layer{"0"};
  Point a{}, b{};                 // LINE endpoints
  Point center{};                 // ARC/CIRCLE center
  double radius{}, start_angle{}, end_angle{}; // degrees, ARC is CCW
  std::vector<Point> points;      // LWPOLYLINE vertices
  std::vector<double> bulges;     // one bulge per vertex; nonzero means curved segment
  bool closed{false};
};
struct Drawing { std::vector<Entity> entities; std::size_t unsupported_entities{}; };
struct RepairReport { std::size_t duplicates_removed{}, endpoints_joined{}, polylines_merged{}; };
struct SimplifyReport { std::size_t before{}, after{}; double max_deviation{}; std::size_t polylines_changed{}; };
struct QualityReport {
  std::size_t entity_count{}, zero_length_lines{}, invalid_radii{}, short_polylines{};
  std::size_t open_polylines{}, self_intersections{}, duplicate_lines{};
};

bool read_ascii_dxf(const std::string& path, Drawing& out, std::string& error);
bool write_ascii_dxf(const std::string& path, const Drawing& drawing, std::string& error);
RepairReport remove_duplicate_lines(Drawing& drawing, double tolerance);
std::size_t join_nearby_polyline_ends(Drawing& drawing, double tolerance);
std::size_t merge_connected_polylines(Drawing& drawing, double tolerance);
SimplifyReport simplify_polylines(Drawing& drawing, double tolerance);
QualityReport inspect_quality(const Drawing& drawing, double tolerance);
double distance(Point a, Point b);
}
