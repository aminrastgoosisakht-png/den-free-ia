#include "den/geometry.hpp"
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
int main(){using namespace den;
  Drawing d;Entity l;l.type=Entity::Type::Line;l.a={0,0};l.b={10,0};l.points={l.a,l.b};d.entities.push_back(l);Entity dup=l;dup.a={10,0};dup.b={0,0};d.entities.push_back(dup);
  auto rr=remove_duplicate_lines(d,1e-8);assert(rr.duplicates_removed==1&&d.entities.size()==1);
  Entity p;p.type=Entity::Type::Polyline;p.points={{0,0},{1,0.01},{2,0},{3,0},{3,2}};p.closed=false;d.entities.push_back(p);auto sr=simplify_polylines(d,0.05);assert(sr.after<sr.before);assert(sr.polylines_changed==1);
  Entity arc;arc.type=Entity::Type::Arc;arc.center={2,3};arc.radius=5;arc.start_angle=0;arc.end_angle=90;d.entities.push_back(arc);Entity c;c.type=Entity::Type::Circle;c.center={1,1};c.radius=2;d.entities.push_back(c);
  std::string err;assert(write_ascii_dxf("den_roundtrip_test.dxf",d,err));Drawing read;assert(read_ascii_dxf("den_roundtrip_test.dxf",read,err));assert(read.entities.size()==d.entities.size());assert(read.entities[2].type==Entity::Type::Arc);assert(std::abs(read.entities[2].radius-5)<1e-9);assert(read.entities[3].type==Entity::Type::Circle);
  Drawing curved;Entity cp;cp.type=Entity::Type::Polyline;cp.points={{0,0},{1,1},{2,0}};cp.bulges={0.5,0,0};curved.entities.push_back(cp);auto curvedBefore=curved.entities[0].points.size();auto cr=simplify_polylines(curved,10.0);assert(cr.before==0&&curved.entities[0].points.size()==curvedBefore);
  Drawing closed;Entity cl;cl.type=Entity::Type::Polyline;cl.closed=true;cl.points={{0,0},{1,0},{1,1},{0,1}};closed.entities.push_back(cl);auto closedBefore=closed.entities[0].points.size();auto clr=simplify_polylines(closed,10.0);assert(clr.before==0&&closed.entities[0].points.size()==closedBefore);
  Drawing qd;Entity bow;bow.type=Entity::Type::Polyline;bow.points={{0,0},{2,2},{0,2},{2,0}};qd.entities.push_back(bow);auto qr=inspect_quality(qd,1e-9);assert(qr.open_polylines==1);assert(qr.self_intersections==1);
  Entity a;a.type=Entity::Type::Polyline;a.layer="A";a.points={{0,0},{1,0}};Entity b;b.type=Entity::Type::Polyline;b.layer="A";b.points={{1.0001,0},{2,0}};Drawing jd;jd.entities={a,b};assert(merge_connected_polylines(jd,0.001)==1);assert(jd.entities.size()==1&&jd.entities[0].points.size()==3);
  // Unsupported entity types must be detected so Android export can fail closed.
  { std::ofstream f("den_unsupported_test.dxf"); f << "0\nSECTION\n2\nENTITIES\n0\nELLIPSE\n8\n0\n0\nENDSEC\n0\nEOF\n"; }
  Drawing unsupported; assert(read_ascii_dxf("den_unsupported_test.dxf", unsupported, err));
  assert(unsupported.unsupported_entities == 1);
  std::cout<<"DEN core tests passed\n";
}
