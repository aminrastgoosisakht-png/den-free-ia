plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.den.cadcleaner"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.den.cadcleaner"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.7.0"
        ndkVersion = "27.0.12077973"
        externalNativeBuild { cmake { cppFlags += "-std=c++20" } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
}
