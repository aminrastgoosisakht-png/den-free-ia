#include <jni.h>
#include <string>
#include "den/geometry.hpp"

extern "C" JNIEXPORT jstring JNICALL
Java_com_den_cadcleaner_MainActivity_processNative(JNIEnv* env, jobject,
    jstring input, jstring output, jdouble tolerance, jboolean removeDuplicates,
    jboolean mergePaths, jboolean simplify) {
    const char* inChars = env->GetStringUTFChars(input, nullptr);
    const char* outChars = env->GetStringUTFChars(output, nullptr);
    std::string inPath(inChars), outPath(outChars);
    env->ReleaseStringUTFChars(input, inChars);
    env->ReleaseStringUTFChars(output, outChars);
    den::Drawing drawing; std::string error;
    if (!den::read_ascii_dxf(inPath, drawing, error)) return env->NewStringUTF(("ERROR: " + error).c_str());
    // Fail closed: never export a partial drawing after silently dropping entities.
    if (drawing.unsupported_entities > 0) {
        return env->NewStringUTF(("ERROR: فایل شامل " + std::to_string(drawing.unsupported_entities) +
            " موجودیت پشتیبانی‌نشده است؛ برای جلوگیری از حذف اطلاعات، خروجی ساخته نشد.").c_str());
    }
    std::size_t before = drawing.entities.size();
    den::RepairReport repair;
    if (removeDuplicates == JNI_TRUE) repair = den::remove_duplicate_lines(drawing, tolerance);
    std::size_t merged = 0;
    if (mergePaths == JNI_TRUE) merged = den::merge_connected_polylines(drawing, tolerance);
    den::SimplifyReport simp;
    if (simplify == JNI_TRUE) simp = den::simplify_polylines(drawing, tolerance);
    if (!den::write_ascii_dxf(outPath, drawing, error)) return env->NewStringUTF(("ERROR: " + error).c_str());
    auto qc = den::inspect_quality(drawing, tolerance);
    std::string result = "OK | entities " + std::to_string(before) + " -> " + std::to_string(drawing.entities.size())
      + " | duplicates removed " + std::to_string(repair.duplicates_removed)
      + " | paths merged " + std::to_string(merged)
      + " | points " + std::to_string(simp.before) + " -> " + std::to_string(simp.after)
      + " | open paths " + std::to_string(qc.open_polylines)
      + " | self intersections " + std::to_string(qc.self_intersections)
      + " | unsupported entities skipped " + std::to_string(drawing.unsupported_entities);
    return env->NewStringUTF(result.c_str());
}
