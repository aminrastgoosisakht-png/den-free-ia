package com.den.cadcleaner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private external fun processNative(
        input: String, output: String, tolerance: Double,
        removeDuplicates: Boolean, mergePaths: Boolean, simplify: Boolean
    ): String

    private val worker = Executors.newSingleThreadExecutor()
    private var source: Uri? = null
    private var preparedOutput: File? = null
    private lateinit var status: TextView
    private lateinit var toleranceInput: EditText
    private lateinit var removeDuplicatesBox: CheckBox
    private lateinit var mergePathsBox: CheckBox
    private lateinit var simplifyBox: CheckBox

    private val pickInputCode = 4101
    private val pickOutputCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            System.loadLibrary("den_native")
        } catch (e: UnsatisfiedLinkError) {
            Toast.makeText(this, "موتور پردازش بارگذاری نشد: ${e.message}", Toast.LENGTH_LONG).show()
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
        }
        val title = TextView(this).apply {
            text = "DEN CAD Cleaner"
            textSize = 25f
        }
        val subtitle = TextView(this).apply {
            text = "پاک‌سازی و آماده‌سازی فایل‌های DXF\nنسخه آزمایشی 0.7.0"
            textSize = 14f
            setPadding(0, 6, 0, 20)
        }
        status = TextView(this).apply {
            text = "برای شروع، یک فایل DXF انتخاب کنید."
            textSize = 15f
            setPadding(0, 18, 0, 18)
        }
        toleranceInput = EditText(this).apply {
            hint = "تلرانس برحسب واحد نقشه؛ مثلاً 0.01"
            setText("0.01")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        removeDuplicatesBox = CheckBox(this).apply { text = "حذف خطوط تکراری"; isChecked = true }
        mergePathsBox = CheckBox(this).apply { text = "ادغام مسیرهای خطی متصل"; isChecked = true }
        simplifyBox = CheckBox(this).apply { text = "کاهش نقاط مسیرهای باز"; isChecked = false }
        val openButton = Button(this).apply {
            text = "۱. انتخاب فایل DXF"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, pickInputCode)
            }
        }
        val processButton = Button(this).apply {
            text = "۲. پردازش و آماده‌سازی خروجی"
            setOnClickListener { processSelected() }
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(status)
        content.addView(toleranceInput)
        content.addView(removeDuplicatesBox)
        content.addView(mergePathsBox)
        content.addView(simplifyBox)
        content.addView(openButton)
        content.addView(processButton)

        val scroll = ScrollView(this).apply {
            addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(scroll)
    }

    private fun processSelected() {
        val inputUri = source
        if (inputUri == null) {
            Toast.makeText(this, "ابتدا فایل ورودی را انتخاب کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val tolerance = toleranceInput.text.toString().toDoubleOrNull()
        if (tolerance == null || !tolerance.isFinite() || tolerance <= 0.0) {
            status.text = "تلرانس باید یک عدد معتبر و بزرگ‌تر از صفر باشد."
            return
        }
        status.text = "در حال پردازش؛ لطفاً صبر کنید..."
        val removeDup = removeDuplicatesBox.isChecked
        val merge = mergePathsBox.isChecked
        val simplify = simplifyBox.isChecked

        worker.execute {
            try {
                val inputFile = File(cacheDir, "den_input_${System.currentTimeMillis()}.dxf")
                val inputStream = requireNotNull(contentResolver.openInputStream(inputUri)) { "خواندن فایل ورودی ممکن نیست" }
                inputStream.use { input -> inputFile.outputStream().use { output -> input.copyTo(output) } }
                val outputFile = File(cacheDir, "den_prepared_${System.currentTimeMillis()}.dxf")
                val report = processNative(inputFile.absolutePath, outputFile.absolutePath, tolerance, removeDup, merge, simplify)
                inputFile.delete()
                runOnUiThread {
                    if (report.startsWith("OK") && outputFile.exists() && outputFile.length() > 0L) {
                        preparedOutput?.delete()
                        preparedOutput = outputFile
                        status.text = "$report\n\nخروجی آماده است. برای انتخاب محل ذخیره لمس کنید."
                        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "application/dxf"
                            putExtra(Intent.EXTRA_TITLE, "DEN_Cleaned.dxf")
                        }
                        startActivityForResult(intent, pickOutputCode)
                    } else {
                        outputFile.delete()
                        status.text = report
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "خطا: ${e.message}" }
            }
        }
    }


    @Deprecated("Legacy activity result API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            pickInputCode -> {
                source = uri
                status.text = "فایل انتخاب شد. فایل اصلی فقط خواندنی است و تغییر نمی‌کند."
            }
            pickOutputCode -> savePreparedOutput(uri)
        }
    }

    private fun savePreparedOutput(uri: Uri) {
        val file = preparedOutput
        if (file == null || !file.exists()) {
            status.text = "فایل خروجی موقت پیدا نشد؛ دوباره پردازش کنید."
            return
        }
        try {
            contentResolver.openOutputStream(uri, "w").use { output ->
                requireNotNull(output) { "ایجاد فایل مقصد ممکن نیست" }
                file.inputStream().use { input -> input.copyTo(output) }
            }
            file.delete()
            preparedOutput = null
            status.append("\n\nذخیره با موفقیت انجام شد.")
            Toast.makeText(this, "فایل جدید ذخیره شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.append("\nخطا در ذخیره: ${e.message}")
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
